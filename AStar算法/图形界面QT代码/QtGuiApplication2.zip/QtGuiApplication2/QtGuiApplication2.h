#pragma once

#include <QtWidgets/QMainWindow>
#include <vector>
#include <qtextbrowser.h>
#include <qpushbutton.h>
#include "ui_QtGuiApplication2.h"

using namespace std;

class QtGuiApplication2 : public QMainWindow
{
	Q_OBJECT

public:
	QtGuiApplication2(QWidget *parent = Q_NULLPTR);
	void setNumber(vector<vector<int>> v);
	void setResult(vector<vector<vector<int>>> v);

private:
	Ui::QtGuiApplication2Class ui;
	vector<vector<vector<int>>> result;
	int i;

private slots:
	void on_pushButton_clicked();
};
