#include "QtGuiApplication2.h"

QtGuiApplication2::QtGuiApplication2(QWidget *parent)
	: QMainWindow(parent){
	ui.setupUi(this);
	i = 0;
}

void QtGuiApplication2::setNumber(vector<vector<int>> v) {
	QTextBrowser* puzzle1 = ui.puzzle1;
	QTextBrowser* puzzle2 = ui.puzzle2;
	QTextBrowser* puzzle3 = ui.puzzle3;
	QTextBrowser* puzzle4 = ui.puzzle4;
	QTextBrowser* puzzle5 = ui.puzzle5;
	QTextBrowser* puzzle6 = ui.puzzle6;
	QTextBrowser* puzzle7 = ui.puzzle7;
	QTextBrowser* puzzle8 = ui.puzzle8;
	QTextBrowser* puzzle9 = ui.puzzle9;

	puzzle1->setText(v[0][0] == 0 ? "" : "  " + QString::number(v[0][0]));
	puzzle2->setText(v[0][1] == 0 ? "" : "  " + QString::number(v[0][1]));
	puzzle3->setText(v[0][2] == 0 ? "" : "  " + QString::number(v[0][2]));
	puzzle4->setText(v[1][0] == 0 ? "" : "  " + QString::number(v[1][0]));
	puzzle5->setText(v[1][1] == 0 ? "" : "  " + QString::number(v[1][1]));
	puzzle6->setText(v[1][2] == 0 ? "" : "  " + QString::number(v[1][2]));
	puzzle7->setText(v[2][0] == 0 ? "" : "  " + QString::number(v[2][0]));
	puzzle8->setText(v[2][1] == 0 ? "" : "  " + QString::number(v[2][1]));
	puzzle9->setText(v[2][2] == 0 ? "" : "  " + QString::number(v[2][2]));

	puzzle1->setFont(QFont("Times", 30, QFont::Bold));
	puzzle2->setFont(QFont("Times", 30, QFont::Bold));
	puzzle3->setFont(QFont("Times", 30, QFont::Bold));
	puzzle4->setFont(QFont("Times", 30, QFont::Bold));
	puzzle5->setFont(QFont("Times", 30, QFont::Bold));
	puzzle6->setFont(QFont("Times", 30, QFont::Bold));
	puzzle7->setFont(QFont("Times", 30, QFont::Bold));
	puzzle8->setFont(QFont("Times", 30, QFont::Bold));
	puzzle9->setFont(QFont("Times", 30, QFont::Bold));

	puzzle1->repaint();
	puzzle2->repaint();
	puzzle3->repaint();
	puzzle4->repaint();
	puzzle5->repaint();
	puzzle6->repaint();
	puzzle7->repaint();
	puzzle8->repaint();
	puzzle9->repaint();
}

void QtGuiApplication2::setResult(vector<vector<vector<int>>> v) {
	result = v;
	setNumber(result[i]);
}


void QtGuiApplication2::on_pushButton_clicked(){
	i++;
	if (i < result.size()) {
		setNumber(result[i]);
	}
}